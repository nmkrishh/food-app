import { useMemo, useState } from 'react';
import { T } from '../theme';
import FoodCard from '../components/FoodCard';
import FilterSheet from '../components/FilterSheet';
import { normalizeMenuItem } from '../utils/menuItem';

function normalizeItems(items, categoryId) {
  return items.map(item => normalizeMenuItem(item, categoryId));
}

export default function CategoryPageView({ categories, menuItems, categoryId, cart, cartActions, onBack, onSearchOpen, onItemOpen, onInitialAdd, itemSelections }) {
  const [activeCategoryId, setActiveCategoryId] = useState(categoryId);
  const [activeSort, setActiveSort] = useState(null);
  const [activeSpicy, setActiveSpicy] = useState(false);
  const [vegOn, setVegOn] = useState(false);
  const [nonvegOn, setNonvegOn] = useState(false);
  const [filterOpen, setFilterOpen] = useState(false);

  const currentItems = useMemo(() => normalizeItems(menuItems[activeCategoryId] || [], activeCategoryId), [activeCategoryId, menuItems]);

  const filtered = useMemo(() => {
    let items = [...currentItems];
    if (activeSpicy) {
      items = items.filter(item => {
        const text = `${item.name} ${item.desc}`.toLowerCase();
        return text.includes('spicy') || text.includes('chilli') || text.includes('chili') || item.name.includes('🌶️');
      });
    }
    if (vegOn) items = items.filter(item => item.isVeg);
    if (nonvegOn) items = items.filter(item => !item.isVeg);
    if (activeSort === 'low-high') items = [...items].sort((a, b) => a.price - b.price);
    if (activeSort === 'high-low') items = [...items].sort((a, b) => b.price - a.price);
    return items;
  }, [activeSort, activeSpicy, currentItems, nonvegOn, vegOn]);

  const selectedFilterCount = [activeSort, activeSpicy, vegOn, nonvegOn].filter(Boolean).length;

  return (
    <div style={{ minHeight: '100vh', background: '#f2f2f2', paddingBottom: 100, fontFamily: T.font }}>
      <div style={{ position: 'sticky', top: 0, zIndex: 50, background: 'rgba(250,247,242,0.92)', backdropFilter: 'blur(20px)', WebkitBackdropFilter: 'blur(20px)', borderBottom: '1px solid rgba(210,195,178,0.35)', boxShadow: '0 8px 18px rgba(96,72,44,0.08)' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '14px 16px 10px' }}>
          <button onClick={onBack} style={iconBtn}>←</button>
          <span style={{ fontSize: 15, fontWeight: 800, color: '#1e1810' }}>{categories.find(c => c.id === activeCategoryId)?.name || 'Category'}</span>
          <div style={{ display: 'flex', gap: 8 }}>
            <button onClick={onSearchOpen} style={searchBtn} aria-label="Open search">
              <span className="material-symbols-outlined" style={{ color: '#2d2926', fontSize: 26, lineHeight: 1 }}>search</span>
            </button>
          </div>
        </div>

        <div style={{ overflowX: 'auto', display: 'flex', scrollbarWidth: 'none', paddingBottom: 2 }}>
          {categories.map(cat => {
            const selected = cat.id === activeCategoryId;
            return (
              <button
                key={cat.id}
                onClick={() => setActiveCategoryId(cat.id)}
                style={{
                  flexShrink: 0,
                  padding: '8px 14px 10px',
                  background: 'none',
                  border: 'none',
                  cursor: 'pointer',
                  whiteSpace: 'nowrap',
                  borderBottom: selected ? `2.5px solid ${T.accent}` : '2.5px solid transparent',
                  fontWeight: selected ? 800 : 500,
                  fontSize: 12,
                  color: selected ? T.accent : T.textMuted,
                  fontFamily: T.font,
                }}
              >
                {cat.name}
              </button>
            );
          })}
        </div>

        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, padding: '10px 12px 12px' }}>
          <PillButton onClick={() => setFilterOpen(true)} active={selectedFilterCount > 0}>
            <span className="material-symbols-outlined" style={{ fontSize: 18, color: '#242021' }}>filter_list</span>
            <span style={{ fontWeight: 700, fontSize: 13, color: '#000' }}>{selectedFilterCount > 0 ? `Filter (${selectedFilterCount})` : 'Filter'}</span>
          </PillButton>

          <PillButton>
            <label style={{ position: 'relative', display: 'inline-flex', alignItems: 'center', width: 55, height: 24, cursor: 'pointer', padding: '5px 10px' }}>
              <input
                type="checkbox"
                className="veg-checkbox"
                checked={vegOn}
                onChange={e => {
                  const checked = e.target.checked;
                  setVegOn(checked);
                  if (checked) setNonvegOn(false);
                }}
                style={{ opacity: 0, width: 0, height: 0 }}
              />
              <span className="veg-slider" />
            </label>
          </PillButton>

          <PillButton>
            <label style={{ position: 'relative', display: 'inline-flex', alignItems: 'center', width: 55, height: 24, cursor: 'pointer' }}>
              <input
                type="checkbox"
                className="nonveg-checkbox"
                checked={nonvegOn}
                onChange={e => {
                  const checked = e.target.checked;
                  setNonvegOn(checked);
                  if (checked) setVegOn(false);
                }}
                style={{ opacity: 0, width: 0, height: 0 }}
              />
              <span className="nonveg-slider" />
            </label>
          </PillButton>

          <PillButton active={activeSpicy} onClick={() => setActiveSpicy(prev => !prev)}>
            <span style={{ fontWeight: 700, fontSize: 13, color: activeSpicy ? '#c0392b' : '#000' }}>🌶️ Spicy</span>
          </PillButton>
        </div>
      </div>

      <div style={{ padding: '18px 20px 6px' }}>
        <div style={{ fontSize: 18, fontWeight: 900, color: '#1e1810' }}>{categories.find(c => c.id === activeCategoryId)?.name || 'Items'}</div>
        <div style={{ fontSize: 12, color: '#B0A090', marginTop: 3 }}>{filtered.length} items available</div>
      </div>

      {filtered.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '64px 20px', color: '#999' }}>No items found</div>
      ) : (
        filtered.map(item => (
          <FoodCard
            key={item.id}
            item={item}
            qty={cart[item.id] || 0}
            onAdd={() => onInitialAdd(item)}
            onIncrease={() => cartActions.inc(item.id)}
            onDecrease={() => cartActions.dec(item.id)}
            onImageClick={onItemOpen}
            selectedCustomization={itemSelections?.[item.id]}
          />
        ))
      )}

      <FilterSheet
        open={filterOpen}
        onClose={() => setFilterOpen(false)}
        vegOn={vegOn}
        nonvegOn={nonvegOn}
        activeSort={activeSort}
        activeSpicy={activeSpicy}
        onApply={({ sort, spicy, veg, nonveg }) => {
          setActiveSort(sort);
          setActiveSpicy(spicy);
          setVegOn(veg);
          setNonvegOn(nonveg);
        }}
        onClear={() => {
          setActiveSort(null);
          setActiveSpicy(false);
          setVegOn(false);
          setNonvegOn(false);
        }}
      />

    </div>
  );
}

const iconBtn = {
  width: 34,
  height: 34,
  borderRadius: '50%',
  background: 'rgba(255,255,255,0.88)',
  border: '1px solid rgba(210,195,178,0.35)',
  boxShadow: '0 4px 12px rgba(100,70,40,0.08)',
  cursor: 'pointer',
};

const searchBtn = {
  width: 58,
  height: 46,
  border: 'none',
  borderRadius: 999,
  background: 'linear-gradient(180deg, rgba(198,196,196,0.98) 0%, rgba(165,163,163,0.98) 100%)',
  boxShadow: 'inset 0 1px 0 rgba(255,255,255,0.48), 0 6px 16px rgba(0,0,0,0.22)',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  cursor: 'pointer',
};

function PillButton({ children, onClick, active = false }) {
  return (
    <button
      type="button"
      onClick={onClick}
      style={{
        position: 'relative',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 5,
        borderRadius: 999,
        cursor: 'pointer',
        width: 90,
        height: 38,
        padding: 0,
        background: active ? 'rgba(255,60,0,0.12)' : 'rgba(255,255,255,0.72)',
        backdropFilter: 'blur(20px) saturate(150%)',
        WebkitBackdropFilter: 'blur(20px) saturate(150%)',
        border: active ? '1.5px solid #c0392b' : '1px solid rgba(255,255,255,0.55)',
        boxShadow: '0 8px 18px rgba(96,72,44,0.08), inset 0 1px 0 rgba(255,255,255,0.65)',
      }}
    >
      {children}
    </button>
  );
};
